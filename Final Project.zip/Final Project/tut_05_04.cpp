#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions
#include <vector> // Include for std::vector


// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpengl/camera.h>

// Define M_PI if not defined
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

using namespace std; // Standard namespace

// Shader program Macro
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
    const char* const WINDOW_TITLE = "Tutorial 5.4"; // Macro for window title

    // Variables for window width and height
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    // Stores the GL data relative to a given mesh
    struct GLMesh
    {
        GLuint vao;         // Handle for the vertex array object
        GLuint vbo;         // Handle for the vertex buffer object
        GLuint nVertices;    // Number of indices of the mesh
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;
    // Mesh data
    GLMesh gCylinderMesh; // Main cylinder mesh data
    GLMesh gLidMesh;      // Lid mesh data
    GLMesh gPlaneMesh;    // Plane mesh data
    GLMesh glightMesh;    // light mesh data
    GLMesh gCubeMesh;     // Cube mesh data
    GLMesh gDockMesh;     // Dock mesh data
    GLMesh gGlassesMesh;
    // Textures
    GLuint gCylinderTextureId;
    GLuint gLidTextureId;
    GLuint gPlaneTextureId;
    GLuint glightTextureId;
    GLuint gCubeTextureId;
    GLuint gDockTextureId;
    GLuint gGlassesTextureId;
    glm::vec2 gUVScale(5.0f, 5.0f);
    GLint gTexWrapMode = GL_REPEAT;

    // Shader program
    GLuint gProgramId;

    // camera
    Camera gCamera(glm::vec3(0.0f, 0.0f, 5.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;

    struct Material {
        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;
        float shininess;
    };

    // Define Light struct
    struct Light {
        glm::vec3 position;
        glm::vec3 ambient;
        glm::vec3 diffuse;
        glm::vec3 specular;
    };
}

// User-defined Function prototypes to initialize the program, set the window size,
// redraw graphics on the window when resized, and render graphics on the screen
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateCylinderMesh(GLMesh& mesh, float radius, float height, int sectors);
void UCreateLidMesh(GLMesh& lid, float radius);
void UCreatePlaneMesh(GLMesh& mesh, float width, float height);
void UCreateLightMesh(GLMesh& mesh, float size);
void UCreateCubeMesh(GLMesh& mesh);
void UCreateDockMesh(GLMesh& mesh);
void UCreateGlassesMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

// Vertex Shader Source Code
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;
layout(location = 1) in vec2 texCoord;

out vec2 fragTexCoord;
out vec3 fragPosition; // Pass vertex position to fragment shader

// Global variables for the transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
    gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
    fragTexCoord = texCoord;
    fragPosition = vec3(model * vec4(position, 1.0)); // calculate vertex position in world space
}
);

// Fragment Shader Source Code
const GLchar* fragmentShaderSource = GLSL(440,
    
    in vec2 fragTexCoord;
in vec3 fragPosition;

out vec4 fragmentColor;

uniform sampler2D uTexture;

struct Material {
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
    float shininess;
};

struct Light {
    vec3 position;
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;
};

void main()
{
    vec3 norm = normalize(vec3(0.0f, 1.0f, 0.0f)); // Example normal, should be passed as a varying from vertex shader

    vec3 lightDir = normalize(vec3(1.0f, 1.0f, 1.0f) - fragPosition); // Calculate light direction using fragPosition
    float diff = max(dot(norm, lightDir), 0.0); // Calculate diffuse component

    // Distance-based attenuation
    float distance = length(fragPosition - vec3(1.0f, 1.0f, 1.0f)); // Distance between fragment and light source
    float attenuation = 1.0 / (1.0 + 0.1 * distance + 0.01 * distance * distance);

    vec3 ambient = vec3(0.1f, 0.1f, 0.1f); // Example ambient color
    vec3 diffuse = vec3(0.4f, 0.4f, 0.4f) * diff * attenuation; // Apply attenuation to diffuse color
    vec3 specular = vec3(0.8f, 0.8f, 0.8f); // Example specular color

    vec3 result = (ambient + diffuse + specular) * texture(uTexture, fragTexCoord).rgb; // Final color

    fragmentColor = vec4(result, 1.0); // Output final color
}
);

// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}

int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    UCreateCylinderMesh(gCylinderMesh, 0.5f, 1.0f, 36);
    UCreateLidMesh(gLidMesh, 0.5f);
    UCreatePlaneMesh(gPlaneMesh, 20.0f, 20.0f);
    UCreateLightMesh(glightMesh, 1.0f);
    UCreateCubeMesh(gCubeMesh);
    UCreateDockMesh(gDockMesh);
    UCreateGlassesMesh(gGlassesMesh);

    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    const char* cylinderTexFilename = "eggshell.png";
    if (!UCreateTexture(cylinderTexFilename, gCylinderTextureId))
    {
        cout << "Failed to load texture " << cylinderTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* lidTexFilename = "silver.png";
    if (!UCreateTexture(lidTexFilename, gLidTextureId))
    {
        cout << "Failed to load texture " << lidTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* planeTexFilename = "wood.png";
    if (!UCreateTexture(planeTexFilename, gPlaneTextureId)) {
        cout << "Failed to load texture " << planeTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* lightTexFilename = "white.png";
    if (!UCreateTexture(lightTexFilename, glightTextureId)) {
        cout << "Failed to load texture " << lightTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* cubeTexFilename = "rubiks.png";
    if (!UCreateTexture(cubeTexFilename, gCubeTextureId)) {
        cout << "Failed to load texture " << cubeTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* dockTexFilename = "textured.png";
    if (!UCreateTexture(dockTexFilename, gDockTextureId)) {
        cout << "Failed to load texture " << dockTexFilename << endl;
        return EXIT_FAILURE;
    }

    const char* glassesTexFilename = "smooth.png";
    if (!UCreateTexture(glassesTexFilename, gGlassesTextureId)) {
        cout << "Failed to load texture " << glassesTexFilename << endl;
        return EXIT_FAILURE;
    }

    // Tell OpenGL for each sampler to which texture unit it belongs to
    glUseProgram(gProgramId);
    glUniform1i(glGetUniformLocation(gProgramId, "uTexture"), 0);

    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    while (!glfwWindowShouldClose(gWindow))
    {
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        UProcessInput(gWindow);
        URender();

        glfwSwapBuffers(gWindow);
        glfwPollEvents();
    }

    // Clean up
    UDestroyShaderProgram(gProgramId);
    UDestroyTexture(gCylinderTextureId);
    UDestroyTexture(gLidTextureId);
    UDestroyTexture(gPlaneTextureId);
    UDestroyTexture(glightTextureId);
    UDestroyTexture(gCubeTextureId);
    UDestroyTexture(gDockTextureId);
    UDestroyTexture(gGlassesTextureId);
    UDestroyMesh(gCylinderMesh);
    UDestroyMesh(gLidMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(glightMesh);
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gDockMesh);
    UDestroyMesh(gGlassesMesh);
    glfwTerminate();
    return EXIT_SUCCESS;
}

// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // Initialize GLFW
    if (!glfwInit())
    {
        cout << "Failed to initialize GLFW" << endl;
        return false;
    }

    // Set GLFW error callback
    glfwSetErrorCallback([](int error, const char* description) {
        cout << "GLFW Error: " << description << endl;
        });

    // Create a GLFW window
    *window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, nullptr, nullptr);
    if (!(*window))
    {
        cout << "Failed to create GLFW window" << endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);

    // Set GLFW callbacks
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // Initialize GLEW
    GLenum glewError = glewInit();
    if (glewError != GLEW_OK)
    {
        cout << "Failed to initialize GLEW: " << glewGetErrorString(glewError) << endl;
        return false;
    }

    // Enable depth testing
    glEnable(GL_DEPTH_TEST);

    // Accept fragment if it closer to the camera than the former one
    glDepthFunc(GL_LESS);

    // Set GLFW swap interval
    glfwSwapInterval(1);

    return true;
}

// Callback function to resize the window
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Process input from the keyboard
void UProcessInput(GLFWwindow* window)
{
    // When ESC is pressed, close the window
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Camera controls
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
}

// Mouse callback function
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates range from bottom to top
    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// Mouse scroll callback function
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// Mouse button callback function
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
        gCamera.Zoom = 45.0f; // Reset FOV
}

// Function to create the mesh for the main cylinder
void UCreateCylinderMesh(GLMesh& mesh, float radius, float height, int sectors) {
    std::vector<float> vertices;
    std::vector<float> texCoords;

    // Generate vertices and texture coordinates for the cylinder
    for (int i = 0; i <= sectors; ++i) {
        float angle = i * (2 * M_PI / sectors);
        float x = radius * cos(angle);
        float z = radius * sin(angle);

        // Bottom circle vertex
        vertices.push_back(x);
        vertices.push_back(-height / 2);
        vertices.push_back(z);

        // Top circle vertex
        vertices.push_back(x);
        vertices.push_back(height / 2);
        vertices.push_back(z);

        // Texture coordinates (cylindrical mapping)
        texCoords.push_back(static_cast<float>(i) / sectors);  // U coordinate
        texCoords.push_back(0.0f);  // V coordinate for bottom
        texCoords.push_back(static_cast<float>(i) / sectors);  // U coordinate
        texCoords.push_back(1.0f);  // V coordinate for top
    }

    mesh.nVertices = vertices.size() / 3;

    // Generate and bind VAO for the cylinder
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Generate VBO for the cylinder vertices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the cylinder vertices
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Generate VBO for the texture coordinates
    GLuint texCoordVbo;
    glGenBuffers(1, &texCoordVbo);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordVbo);
    glBufferData(GL_ARRAY_BUFFER, texCoords.size() * sizeof(float), texCoords.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the texture coordinates
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

// Function to create the mesh for the lid
void UCreateLidMesh(GLMesh& lid, float radius) {
    const int sectors = 36; // Number of sectors for the lid
    std::vector<float> lidVerts;

    // Generate vertices for the lid
    for (int i = 0; i <= sectors; ++i) {
        float angle = i * (2 * M_PI / sectors);
        float x = radius * 1.1 * cos(angle);
        float z = radius * 1.1 * sin(angle);

        // Calculate texture coordinates based on planar mapping
        float u = 0.5f + 0.5f * cos(angle);
        float v = 0.5f + 0.5f * sin(angle);

        // Top circle vertex
        lidVerts.push_back(x);
        lidVerts.push_back(0.5f); // Adjust as needed
        lidVerts.push_back(z);
        lidVerts.push_back(u);
        lidVerts.push_back(v);
    }

    lid.nVertices = lidVerts.size() / 5; // Each vertex has 5 components (x, y, z, u, v)

    // Generate and bind VAO for the lid
    glGenVertexArrays(1, &lid.vao);
    glBindVertexArray(lid.vao);

    // Generate VBO for the lid
    glGenBuffers(1, &lid.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, lid.vbo);
    glBufferData(GL_ARRAY_BUFFER, lidVerts.size() * sizeof(float), lidVerts.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the lid
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

// Function to create the mesh for a plane
void UCreatePlaneMesh(GLMesh& mesh, float width, float height) {
    std::vector<float> vertices = {
        // Positions          
        -width / 2, -0.5f, -height / 2,
         width / 2, -0.5f, -height / 2,
         width / 2, -0.5f,  height / 2,
         width / 2, -0.5f,  height / 2,
        -width / 2, -0.5f,  height / 2,
        -width / 2, -0.5f, -height / 2
    };

    std::vector<float> texCoords = {
        0.0f, 0.0f,
        1.0f, 0.0f,
        1.0f, 1.0f,
        1.0f, 1.0f,
        0.0f, 1.0f,
        0.0f, 0.0f
    };

    mesh.nVertices = vertices.size() / 3;

    // Generate and bind VAO for the plane
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Generate VBO for the plane vertices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the plane vertices
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Generate VBO for the texture coordinates
    GLuint texCoordVbo;
    glGenBuffers(1, &texCoordVbo);
    glBindBuffer(GL_ARRAY_BUFFER, texCoordVbo);
    glBufferData(GL_ARRAY_BUFFER, texCoords.size() * sizeof(float), texCoords.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the texture coordinates
    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}

// Function to create the mesh for a light
void UCreateLightMesh(GLMesh& mesh, float size) {
    // Vertices for a unit light centered at origin
    std::vector<float> vertices = {
        // Front face
        -size / 2, -size / 2, size / 2,
         size / 2, -size / 2, size / 2,
         size / 2,  size / 2, size / 2,
         size / 2,  size / 2, size / 2,
        -size / 2,  size / 2, size / 2,
        -size / 2, -size / 2, size / 2,
        // Back face
        -size / 2, -size / 2, -size / 2,
         size / 2, -size / 2, -size / 2,
         size / 2,  size / 2, -size / 2,
         size / 2,  size / 2, -size / 2,
        -size / 2,  size / 2, -size / 2,
        -size / 2, -size / 2, -size / 2,
        // Right face
         size / 2, -size / 2,  size / 2,
         size / 2, -size / 2, -size / 2,
         size / 2,  size / 2, -size / 2,
         size / 2,  size / 2, -size / 2,
         size / 2,  size / 2,  size / 2,
         size / 2, -size / 2,  size / 2,
         // Left face
         -size / 2, -size / 2,  size / 2,
         -size / 2, -size / 2, -size / 2,
         -size / 2,  size / 2, -size / 2,
         -size / 2,  size / 2, -size / 2,
         -size / 2,  size / 2,  size / 2,
         -size / 2, -size / 2,  size / 2,
         // Top face
         -size / 2,  size / 2,  size / 2,
          size / 2,  size / 2,  size / 2,
          size / 2,  size / 2, -size / 2,
          size / 2,  size / 2, -size / 2,
         -size / 2,  size / 2, -size / 2,
         -size / 2,  size / 2,  size / 2,
         // Bottom face
         -size / 2, -size / 2,  size / 2,
          size / 2, -size / 2,  size / 2,
          size / 2, -size / 2, -size / 2,
          size / 2, -size / 2, -size / 2,
         -size / 2, -size / 2, -size / 2,
         -size / 2, -size / 2,  size / 2
    };

    mesh.nVertices = vertices.size() / 3;

    // Generate and bind VAO for the light
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    // Generate VBO for the light vertices
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(float), vertices.data(), GL_STATIC_DRAW);

    // Set up vertex attributes for the light vertices
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
}

void UCreateCubeMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        //Positions          //Texture Coordinates
       -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
       -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,

       -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
       -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,

       -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

        0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f, 0.0f,

       -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,  1.0f, 1.0f,
        0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
        0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
       -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
       -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,

       -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
        0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
        0.5f,  0.5f,  0.5f,  1.0f, 0.0f,
       -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,
       -0.5f,  0.5f, -0.5f,  0.0f, 1.0f
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Strides between vertex coordinates and texture coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1); // Enable the attribute
}

void UCreateDockMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        // Positions          // Texture Coordinates
       -0.25f, -0.75f, -0.125f,  0.0f, 0.0f,  // Front bottom left
        0.25f, -0.75f, -0.125f,  1.0f, 0.0f,  // Front bottom right
        0.25f,  0.75f, -0.125f,  1.0f, 1.0f,  // Front top right
        0.25f,  0.75f, -0.125f,  1.0f, 1.0f,  // Front top right
       -0.25f,  0.75f, -0.125f,  0.0f, 1.0f,  // Front top left
       -0.25f, -0.75f, -0.125f,  0.0f, 0.0f,  // Front bottom left

       -0.25f, -0.75f,  0.125f,  0.0f, 0.0f,  // Back bottom left
        0.25f, -0.75f,  0.125f,  1.0f, 0.0f,  // Back bottom right
        0.25f,  0.75f,  0.125f,  1.0f, 1.0f,  // Back top right
        0.25f,  0.75f,  0.125f,  1.0f, 1.0f,  // Back top right
       -0.25f,  0.75f,  0.125f,  0.0f, 1.0f,  // Back top left
       -0.25f, -0.75f,  0.125f,  0.0f, 0.0f,  // Back bottom left

       -0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Left top front
       -0.25f,  0.75f, -0.125f,  1.0f, 1.0f,  // Left top back
       -0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Left bottom back
       -0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Left bottom back
       -0.25f, -0.75f,  0.125f,  0.0f, 0.0f,  // Left bottom front
       -0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Left top front

        0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Right top front
        0.25f,  0.75f, -0.125f,  1.0f, 1.0f,  // Right top back
        0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Right bottom back
        0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Right bottom back
        0.25f, -0.75f,  0.125f,  0.0f, 0.0f,  // Right bottom front
        0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Right top front

       -0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Bottom front left
        0.25f, -0.75f, -0.125f,  1.0f, 1.0f,  // Bottom front right
        0.25f, -0.75f,  0.125f,  1.0f, 0.0f,  // Bottom back right
        0.25f, -0.75f,  0.125f,  1.0f, 0.0f,  // Bottom back right
       -0.25f, -0.75f,  0.125f,  0.0f, 0.0f,  // Bottom back left
       -0.25f, -0.75f, -0.125f,  0.0f, 1.0f,  // Bottom front left

       -0.25f,  0.75f, -0.125f,  0.0f, 1.0f,  // Top front left
        0.25f,  0.75f, -0.125f,  1.0f, 1.0f,  // Top front right
        0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Top back right
        0.25f,  0.75f,  0.125f,  1.0f, 0.0f,  // Top back right
       -0.25f,  0.75f,  0.125f,  0.0f, 0.0f,  // Top back left
       -0.25f,  0.75f, -0.125f,  0.0f, 1.0f   // Top front left
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Strides between vertex coordinates and texture coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1); // Enable the attribute
}

void UCreateGlassesMesh(GLMesh& mesh)
{
    // Vertex data
    GLfloat verts[] = {
        // Positions          // Texture Coordinates
       -0.35f, -0.75f, -0.12f,  0.0f, 0.0f,  // Front bottom left
        0.35f, -0.75f, -0.12f,  1.0f, 0.0f,  // Front bottom right
        0.35f,  0.75f, -0.12f,  1.0f, 1.0f,  // Front top right
        0.35f,  0.75f, -0.12f,  1.0f, 1.0f,  // Front top right
       -0.35f,  0.75f, -0.12f,  0.0f, 1.0f,  // Front top left
       -0.35f, -0.75f, -0.12f,  0.0f, 0.0f,  // Front bottom left

       -0.35f, -0.75f,  0.12f,  0.0f, 0.0f,  // Back bottom left
        0.35f, -0.75f,  0.12f,  1.0f, 0.0f,  // Back bottom right
        0.35f,  0.75f,  0.12f,  1.0f, 1.0f,  // Back top right
        0.35f,  0.75f,  0.12f,  1.0f, 1.0f,  // Back top right
       -0.35f,  0.75f,  0.12f,  0.0f, 1.0f,  // Back top left
       -0.35f, -0.75f,  0.12f,  0.0f, 0.0f,  // Back bottom left

       -0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Left top front
       -0.35f,  0.75f, -0.12f,  1.0f, 1.0f,  // Left top back
       -0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Left bottom back
       -0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Left bottom back
       -0.35f, -0.75f,  0.12f,  0.0f, 0.0f,  // Left bottom front
       -0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Left top front

        0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Right top front
        0.35f,  0.75f, -0.12f,  1.0f, 1.0f,  // Right top back
        0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Right bottom back
        0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Right bottom back
        0.35f, -0.75f,  0.12f,  0.0f, 0.0f,  // Right bottom front
        0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Right top front

       -0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Bottom front left
        0.35f, -0.75f, -0.12f,  1.0f, 1.0f,  // Bottom front right
        0.35f, -0.75f,  0.12f,  1.0f, 0.0f,  // Bottom back right
        0.35f, -0.75f,  0.12f,  1.0f, 0.0f,  // Bottom back right
       -0.35f, -0.75f,  0.12f,  0.0f, 0.0f,  // Bottom back left
       -0.35f, -0.75f, -0.12f,  0.0f, 1.0f,  // Bottom front left

       -0.35f,  0.75f, -0.12f,  0.0f, 1.0f,  // Top front left
        0.35f,  0.75f, -0.12f,  1.0f, 1.0f,  // Top front right
        0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Top back right
        0.35f,  0.75f,  0.12f,  1.0f, 0.0f,  // Top back right
       -0.35f,  0.75f,  0.12f,  0.0f, 0.0f,  // Top back left
       -0.35f,  0.75f, -0.12f,  0.0f, 1.0f   // Top front left
    };

    const GLuint floatsPerVertex = 3;
    const GLuint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerUV));

    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);

    // Strides between vertex coordinates and texture coordinates
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerUV);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1); // Enable the attribute
}


// Function to destroy a mesh
void UDestroyMesh(GLMesh& mesh) {
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);
    mesh.nVertices = 0;
}

// Function to load a texture from file
bool UCreateTexture(const char* filename, GLuint& textureId) {
    int width, height, channels;
    stbi_set_flip_vertically_on_load(true); // This line flips the image vertically during loading
    unsigned char* image = stbi_load(filename, &width, &height, &channels, STBI_rgb_alpha);
    if (!image) {
        cerr << "Failed to load texture: " << filename << endl;
        return false;
    }

    glGenTextures(1, &textureId);
    glBindTexture(GL_TEXTURE_2D, textureId);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image); // Free the image data after it's been loaded into OpenGL

    return true;
}

// Function to destroy a texture
void UDestroyTexture(GLuint textureId) {
    glDeleteTextures(1, &textureId);
}

// Function to render the scene
void URender() {
    // Clear the color and depth buffers
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use the shader program
    glUseProgram(gProgramId);

    // Set up transformations
    glm::mat4 model = glm::mat4(1.0f);
    glm::mat4 view = gCamera.GetViewMatrix();
    glm::mat4 projection = glm::perspective(glm::radians(gCamera.Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Pass Material data to the shaders
    Material material;
    material.ambient = glm::vec3(0.1f, 0.1f, 0.1f);
    material.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
    material.specular = glm::vec3(1.0f, 1.0f, 1.0f);
    material.shininess = 32.0f;

    GLuint materialAmbientLoc = glGetUniformLocation(gProgramId, "material.ambient");
    GLuint materialDiffuseLoc = glGetUniformLocation(gProgramId, "material.diffuse");
    GLuint materialSpecularLoc = glGetUniformLocation(gProgramId, "material.specular");
    GLuint materialShininessLoc = glGetUniformLocation(gProgramId, "material.shininess");

    glUniform3fv(materialAmbientLoc, 1, glm::value_ptr(material.ambient));
    glUniform3fv(materialDiffuseLoc, 1, glm::value_ptr(material.diffuse));
    glUniform3fv(materialSpecularLoc, 1, glm::value_ptr(material.specular));
    glUniform1f(materialShininessLoc, material.shininess);

    // Pass Light data to the shaders
    Light light;
    light.position = glm::vec3(1.0f, 1.0f, 1.0f);
    light.ambient = glm::vec3(0.2f, 0.2f, 0.2f);
    light.diffuse = glm::vec3(0.5f, 0.5f, 0.5f);
    light.specular = glm::vec3(1.0f, 1.0f, 1.0f);

    GLuint lightPosLoc = glGetUniformLocation(gProgramId, "light.position");
    GLuint lightAmbientLoc = glGetUniformLocation(gProgramId, "light.ambient");
    GLuint lightDiffuseLoc = glGetUniformLocation(gProgramId, "light.diffuse");
    GLuint lightSpecularLoc = glGetUniformLocation(gProgramId, "light.specular");

    glUniform3fv(lightPosLoc, 1, glm::value_ptr(light.position));
    glUniform3fv(lightAmbientLoc, 1, glm::value_ptr(light.ambient));
    glUniform3fv(lightDiffuseLoc, 1, glm::value_ptr(light.diffuse));
    glUniform3fv(lightSpecularLoc, 1, glm::value_ptr(light.specular));

    // Pass transformation matrices to the shader
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "view"), 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

    // Render the cylinder
    glBindTexture(GL_TEXTURE_2D, gCylinderTextureId);
    glBindVertexArray(gCylinderMesh.vao);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, gCylinderMesh.nVertices);

    // Render the lid
    glBindTexture(GL_TEXTURE_2D, gLidTextureId);
    glBindVertexArray(gLidMesh.vao);
    glDrawArrays(GL_TRIANGLE_FAN, 0, gLidMesh.nVertices);

    // Render the plane
    glBindTexture(GL_TEXTURE_2D, gPlaneTextureId);
    glBindVertexArray(gPlaneMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gPlaneMesh.nVertices);

    // Render the Cube
    glm::mat4 modelCube = glm::mat4(1.0f);
    modelCube = glm::translate(modelCube, glm::vec3(0.2f, -0.22f, 1.0f));
    modelCube = glm::scale(modelCube, glm::vec3(0.55f));
    modelCube = glm::rotate(modelCube, glm::radians(-10.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(modelCube));

    glBindTexture(GL_TEXTURE_2D, gCubeTextureId);
    glBindVertexArray(gCubeMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gCubeMesh.nVertices);

    // Render the Dock
    glm::mat4 modelDock = glm::mat4(1.0f);
    modelDock = glm::translate(modelDock, glm::vec3(0.82f, 0.23f, 0.0f));
    modelDock = glm::scale(modelDock, glm::vec3(1.0f));
    modelDock = glm::rotate(modelDock, glm::radians(90.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    modelDock = glm::rotate(modelDock, glm::radians(-25.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(modelDock));

    glBindTexture(GL_TEXTURE_2D, gDockTextureId);
    glBindVertexArray(gDockMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gDockMesh.nVertices);

    // Render the Glasses case
    glm::mat4 modelGlasses = glm::mat4(1.0f);
    modelGlasses = glm::translate(modelGlasses, glm::vec3(-1.0f, -0.37f, 0.75f));
    modelGlasses = glm::scale(modelGlasses, glm::vec3(1.0f));
    modelGlasses = glm::rotate(modelGlasses, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    modelGlasses = glm::rotate(modelGlasses, glm::radians(-25.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(modelGlasses));

    glBindTexture(GL_TEXTURE_2D, gGlassesTextureId);
    glBindVertexArray(gGlassesMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gGlassesMesh.nVertices);

    // Render the light
    glm::mat4 modellight = glm::mat4(1.0f);
    modellight = glm::translate(modellight, glm::vec3(3.0f, 3.0f, 3.0f)); // Move the light away from the cylinder
    modellight = glm::scale(modellight, glm::vec3(0.25f)); // Make the light smaller
    glUniformMatrix4fv(glGetUniformLocation(gProgramId, "model"), 1, GL_FALSE, glm::value_ptr(modellight));

    glBindTexture(GL_TEXTURE_2D, glightTextureId);
    glBindVertexArray(glightMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, glightMesh.nVertices);

    // Unbind the vertex array and shader program
    glBindVertexArray(0);
    glUseProgram(0);
}

// Function to create a shader program from source code
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compiling vertex shader
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glCompileShader(vertexShaderId);

    GLint success;
    GLchar infoLog[512];
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        cout << "Vertex shader compilation failed: " << infoLog << endl;
        return false;
    }

    // Compiling fragment shader
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);
    glCompileShader(fragmentShaderId);

    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, 512, NULL, infoLog);
        cout << "Fragment shader compilation failed: " << infoLog << endl;
        return false;
    }

    // Creating shader program
    programId = glCreateProgram();
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);
    glLinkProgram(programId);

    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, 512, NULL, infoLog);
        cout << "Shader program linking failed: " << infoLog << endl;
        return false;
    }

    // Clean up
    glDeleteShader(vertexShaderId);
    glDeleteShader(fragmentShaderId);

    return true;
}

// Function to destroy a shader program
void UDestroyShaderProgram(GLuint programId) {
    glDeleteProgram(programId);
}
